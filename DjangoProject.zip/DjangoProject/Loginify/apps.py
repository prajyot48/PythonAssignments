from django.apps import AppConfig


class LoginifyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Loginify"
